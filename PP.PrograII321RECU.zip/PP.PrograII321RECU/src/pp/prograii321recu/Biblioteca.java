package pp.prograii321recu;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private List<Publicacion> publicaciones;

    public Biblioteca() {
        publicaciones = new ArrayList<>();
    }

    public void agregarPublicacion(Publicacion p) throws ExceptionPublicacionExistente {
        for (Publicacion pub : publicaciones) {
            if (pub.equals(p)) {
                throw new ExceptionPublicacionExistente("La publicación ya existe.");
            }
        }
        publicaciones.add(p);
    }

    
    public void mostrarPublicaciones() {
        for (Publicacion pub : publicaciones) {
            System.out.println(pub.toString());
        }
    }

    public void leerPublicaciones() {
        for (Publicacion pub : publicaciones) {
            if (pub instanceof ILeible iLeible) {
                iLeible.leer();
            } else {
                System.out.println("No es posible leer: " + pub.getTitulo());
            }
        }
    }
}