package pp.prograii321recu;

public class Main {
    public static void main(String[] args) {
        try {
            // Instancio publicaciones
            Libro libro1 = new Libro("Biblia", 1455, "Dios", EGenero.FICCION);
            Revista revista1 = new Revista("Avon", 2023, 345);
            Ilustracion ilustracion1 = new Ilustracion("Mafalda", 1964, "Quino", 30, 100);

            // Instancio biblioteca
            Biblioteca biblioteca = new Biblioteca();

            // Agrego las publicaciones
            biblioteca.agregarPublicacion(libro1);
            biblioteca.agregarPublicacion(revista1);
            biblioteca.agregarPublicacion(ilustracion1);
            
            // Muestro las publicaciones
            biblioteca.mostrarPublicaciones();

            // Leo las publicaciones
            biblioteca.leerPublicaciones();
        } catch (ExceptionPublicacionExistente e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}