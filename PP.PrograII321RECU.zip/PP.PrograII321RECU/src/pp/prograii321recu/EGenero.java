package pp.prograii321recu;

public enum EGenero {
    FICCION,
    NO_FICCION,
    CIENCIA,
    HISTORIA
}
