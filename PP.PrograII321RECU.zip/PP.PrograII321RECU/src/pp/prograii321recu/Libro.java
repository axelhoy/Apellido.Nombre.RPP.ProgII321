package pp.prograii321recu;
public class Libro extends Publicacion implements ILeible {
    private String autor;
    private EGenero genero;

    public Libro(String titulo, int anioPublicacion, String autor, EGenero genero) {
        super(titulo, anioPublicacion);
        this.autor = autor;
        this.genero = genero;
    }

    @Override
    public void leer() {
        System.out.println("Leyendo el libro: " + getTitulo());
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName().toString() +" [autor=" + autor + ", genero=" + genero + "]";
    }
}