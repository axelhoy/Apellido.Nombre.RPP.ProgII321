package pp.prograii321recu;
public interface ILeible {
    void leer();
}
