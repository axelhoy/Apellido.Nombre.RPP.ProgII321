package pp.prograii321recu;
public class ExceptionPublicacionExistente extends Exception{
        public ExceptionPublicacionExistente(String mensaje) {
        super(mensaje);
        
    }
}
